Login-Termuxv2
Mirip 98% linux
Penginstallan:
$git clone 
https://github.com/Harisgitama/login-termuxv2fx.git
$cd login-termuxv2fx
$python2 setup.py
$cd ..
$python2 useradd.py
###ENJOY###

(LAKUKAN PENGINSTALLAN HANYA 1X!)
(JIKA SUDAH TERINSTALL JANGAN MENGULANG LAGI!)

command:
$useradd : Untuk Menambahkan user Baru
$passwd : Untuk Mengganti Pw Baru
$info : Untuk Menampilkan Data User
$me : Untuk Melihat Author/Pembuat Script ini

[FREE,JIKA ADA YG MENJUAL SCRIPT INI HARAP LAPOR AUTHOR]
Fb : Haris Gitama
